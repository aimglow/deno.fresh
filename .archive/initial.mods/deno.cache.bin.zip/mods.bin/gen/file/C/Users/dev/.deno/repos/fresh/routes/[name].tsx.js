import { jsxs as _jsxs } from "preact/jsx-runtime";
export default function Greet(props) {
    return /*#__PURE__*/ _jsxs("div", {
        children: [
            "Hello ",
            props.params.name
        ]
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvZGV2Ly5kZW5vL3JlcG9zL2ZyZXNoL3JvdXRlcy9bbmFtZV0udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBhZ2VQcm9wcyB9IGZyb20gXCIkZnJlc2gvc2VydmVyLnRzXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEdyZWV0KHByb3BzOiBQYWdlUHJvcHMpIHtcbiAgcmV0dXJuIDxkaXY+SGVsbG8ge3Byb3BzLnBhcmFtcy5uYW1lfTwvZGl2Pjtcbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUVBLGVBQWUsU0FBUyxNQUFNLEtBQWdCLEVBQUU7SUFDOUMscUJBQU8sTUFBQzs7WUFBSTtZQUFPLE1BQU0sTUFBTSxDQUFDLElBQUk7OztBQUN0QyxDQUFDIn0=