import { jsx as _jsx, jsxs as _jsxs } from "preact/jsx-runtime";
import { useState } from "preact/hooks";
import { Button } from "../components/Button.tsx";
export default function Counter(props) {
    const [count, setCount] = useState(props.start);
    return /*#__PURE__*/ _jsxs("div", {
        class: "flex gap-2 w-full",
        children: [
            /*#__PURE__*/ _jsx("p", {
                class: "flex-grow-1 font-bold text-xl",
                children: count
            }),
            /*#__PURE__*/ _jsx(Button, {
                onClick: ()=>setCount(count - 1),
                children: "-1"
            }),
            /*#__PURE__*/ _jsx(Button, {
                onClick: ()=>setCount(count + 1),
                children: "+1"
            })
        ]
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvZGV2Ly5kZW5vL3JlcG9zL2ZyZXNoL2lzbGFuZHMvQ291bnRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicHJlYWN0L2hvb2tzXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vY29tcG9uZW50cy9CdXR0b24udHN4XCI7XG5cbmludGVyZmFjZSBDb3VudGVyUHJvcHMge1xuICBzdGFydDogbnVtYmVyO1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDb3VudGVyKHByb3BzOiBDb3VudGVyUHJvcHMpIHtcbiAgY29uc3QgW2NvdW50LCBzZXRDb3VudF0gPSB1c2VTdGF0ZShwcm9wcy5zdGFydCk7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzcz1cImZsZXggZ2FwLTIgdy1mdWxsXCI+XG4gICAgICA8cCBjbGFzcz1cImZsZXgtZ3Jvdy0xIGZvbnQtYm9sZCB0ZXh0LXhsXCI+e2NvdW50fTwvcD5cbiAgICAgIDxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0Q291bnQoY291bnQgLSAxKX0+LTE8L0J1dHRvbj5cbiAgICAgIDxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0Q291bnQoY291bnQgKyAxKX0+KzE8L0J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLFNBQVMsUUFBUSxRQUFRLGVBQWU7QUFDeEMsU0FBUyxNQUFNLFFBQVEsMkJBQTJCO0FBTWxELGVBQWUsU0FBUyxRQUFRLEtBQW1CLEVBQUU7SUFDbkQsTUFBTSxDQUFDLE9BQU8sU0FBUyxHQUFHLFNBQVMsTUFBTSxLQUFLO0lBQzlDLHFCQUNFLE1BQUM7UUFBSSxPQUFNOzswQkFDVCxLQUFDO2dCQUFFLE9BQU07MEJBQWlDOzswQkFDMUMsS0FBQztnQkFBTyxTQUFTLElBQU0sU0FBUyxRQUFROzBCQUFJOzswQkFDNUMsS0FBQztnQkFBTyxTQUFTLElBQU0sU0FBUyxRQUFROzBCQUFJOzs7O0FBR2xELENBQUMifQ==