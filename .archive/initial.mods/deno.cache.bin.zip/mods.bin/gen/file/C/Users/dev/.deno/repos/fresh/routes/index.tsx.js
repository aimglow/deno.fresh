import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "preact/jsx-runtime";
import { Head } from "$fresh/runtime.ts";
import Counter from "../islands/Counter.tsx";
export default function Home() {
    return /*#__PURE__*/ _jsxs(_Fragment, {
        children: [
            /*#__PURE__*/ _jsx(Head, {
                children: /*#__PURE__*/ _jsx("title", {
                    children: "Fresh App"
                })
            }),
            /*#__PURE__*/ _jsxs("div", {
                class: "p-4 mx-auto max-w-screen-md",
                children: [
                    /*#__PURE__*/ _jsx("img", {
                        src: "/logo.svg",
                        class: "w-32 h-32",
                        alt: "the fresh logo: a sliced lemon dripping with juice"
                    }),
                    /*#__PURE__*/ _jsx("p", {
                        class: "my-6",
                        children: "Welcome to `fresh`. Try updating this message in the ./routes/index.tsx file, and refresh."
                    }),
                    /*#__PURE__*/ _jsx(Counter, {
                        start: 3
                    })
                ]
            })
        ]
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvZGV2Ly5kZW5vL3JlcG9zL2ZyZXNoL3JvdXRlcy9pbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSGVhZCB9IGZyb20gXCIkZnJlc2gvcnVudGltZS50c1wiO1xuaW1wb3J0IENvdW50ZXIgZnJvbSBcIi4uL2lzbGFuZHMvQ291bnRlci50c3hcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT5GcmVzaCBBcHA8L3RpdGxlPlxuICAgICAgPC9IZWFkPlxuICAgICAgPGRpdiBjbGFzcz1cInAtNCBteC1hdXRvIG1heC13LXNjcmVlbi1tZFwiPlxuICAgICAgICA8aW1nXG4gICAgICAgICAgc3JjPVwiL2xvZ28uc3ZnXCJcbiAgICAgICAgICBjbGFzcz1cInctMzIgaC0zMlwiXG4gICAgICAgICAgYWx0PVwidGhlIGZyZXNoIGxvZ286IGEgc2xpY2VkIGxlbW9uIGRyaXBwaW5nIHdpdGgganVpY2VcIlxuICAgICAgICAvPlxuICAgICAgICA8cCBjbGFzcz1cIm15LTZcIj5cbiAgICAgICAgICBXZWxjb21lIHRvIGBmcmVzaGAuIFRyeSB1cGRhdGluZyB0aGlzIG1lc3NhZ2UgaW4gdGhlIC4vcm91dGVzL2luZGV4LnRzeFxuICAgICAgICAgIGZpbGUsIGFuZCByZWZyZXNoLlxuICAgICAgICA8L3A+XG4gICAgICAgIDxDb3VudGVyIHN0YXJ0PXszfSAvPlxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gICk7XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxTQUFTLElBQUksUUFBUSxvQkFBb0I7QUFDekMsT0FBTyxhQUFhLHlCQUF5QjtBQUU3QyxlQUFlLFNBQVMsT0FBTztJQUM3QixxQkFDRTs7MEJBQ0UsS0FBQzswQkFDQyxjQUFBLEtBQUM7OEJBQU07OzswQkFFVCxNQUFDO2dCQUFJLE9BQU07O2tDQUNULEtBQUM7d0JBQ0MsS0FBSTt3QkFDSixPQUFNO3dCQUNOLEtBQUk7O2tDQUVOLEtBQUM7d0JBQUUsT0FBTTtrQ0FBTzs7a0NBSWhCLEtBQUM7d0JBQVEsT0FBTzs7Ozs7O0FBSXhCLENBQUMifQ==