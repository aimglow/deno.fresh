import { jsx as _jsx } from "preact/jsx-runtime";
import { IS_BROWSER } from "$fresh/runtime.ts";
export function Button(props) {
    return /*#__PURE__*/ _jsx("button", {
        ...props,
        disabled: !IS_BROWSER || props.disabled,
        class: "px-2 py-1 border(gray-100 2) hover:bg-gray-200"
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvZGV2Ly5kZW5vL3JlcG9zL2ZyZXNoL2NvbXBvbmVudHMvQnV0dG9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBKU1ggfSBmcm9tIFwicHJlYWN0XCI7XG5pbXBvcnQgeyBJU19CUk9XU0VSIH0gZnJvbSBcIiRmcmVzaC9ydW50aW1lLnRzXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBCdXR0b24ocHJvcHM6IEpTWC5IVE1MQXR0cmlidXRlczxIVE1MQnV0dG9uRWxlbWVudD4pIHtcbiAgcmV0dXJuIChcbiAgICA8YnV0dG9uXG4gICAgICB7Li4ucHJvcHN9XG4gICAgICBkaXNhYmxlZD17IUlTX0JST1dTRVIgfHwgcHJvcHMuZGlzYWJsZWR9XG4gICAgICBjbGFzcz1cInB4LTIgcHktMSBib3JkZXIoZ3JheS0xMDAgMikgaG92ZXI6YmctZ3JheS0yMDBcIlxuICAgIC8+XG4gICk7XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQSxTQUFTLFVBQVUsUUFBUSxvQkFBb0I7QUFFL0MsT0FBTyxTQUFTLE9BQU8sS0FBNEMsRUFBRTtJQUNuRSxxQkFDRSxLQUFDO1FBQ0UsR0FBRyxLQUFLO1FBQ1QsVUFBVSxDQUFDLGNBQWMsTUFBTSxRQUFRO1FBQ3ZDLE9BQU07O0FBR1osQ0FBQyJ9