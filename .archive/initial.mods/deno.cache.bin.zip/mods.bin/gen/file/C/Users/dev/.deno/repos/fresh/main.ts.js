/// <reference no-default-lib="true" />
/// <reference lib="dom" />
/// <reference lib="dom.iterable" />
/// <reference lib="dom.asynciterable" />
/// <reference lib="deno.ns" />
import { start } from "$fresh/server.ts";
import manifest from "./fresh.gen.ts";
import twindPlugin from "$fresh/plugins/twind.ts";
import twindConfig from "./twind.config.ts";
await start(manifest, {
    plugins: [
        twindPlugin(twindConfig)
    ]
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvZGV2Ly5kZW5vL3JlcG9zL2ZyZXNoL21haW4udHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8vIDxyZWZlcmVuY2Ugbm8tZGVmYXVsdC1saWI9XCJ0cnVlXCIgLz5cbi8vLyA8cmVmZXJlbmNlIGxpYj1cImRvbVwiIC8+XG4vLy8gPHJlZmVyZW5jZSBsaWI9XCJkb20uaXRlcmFibGVcIiAvPlxuLy8vIDxyZWZlcmVuY2UgbGliPVwiZG9tLmFzeW5jaXRlcmFibGVcIiAvPlxuLy8vIDxyZWZlcmVuY2UgbGliPVwiZGVuby5uc1wiIC8+XG5cbmltcG9ydCB7IHN0YXJ0IH0gZnJvbSBcIiRmcmVzaC9zZXJ2ZXIudHNcIjtcbmltcG9ydCBtYW5pZmVzdCBmcm9tIFwiLi9mcmVzaC5nZW4udHNcIjtcblxuaW1wb3J0IHR3aW5kUGx1Z2luIGZyb20gXCIkZnJlc2gvcGx1Z2lucy90d2luZC50c1wiO1xuaW1wb3J0IHR3aW5kQ29uZmlnIGZyb20gXCIuL3R3aW5kLmNvbmZpZy50c1wiO1xuXG5hd2FpdCBzdGFydChtYW5pZmVzdCwgeyBwbHVnaW5zOiBbdHdpbmRQbHVnaW4odHdpbmRDb25maWcpXSB9KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSx1Q0FBdUM7QUFDdkMsMkJBQTJCO0FBQzNCLG9DQUFvQztBQUNwQyx5Q0FBeUM7QUFDekMsK0JBQStCO0FBRS9CLFNBQVMsS0FBSyxRQUFRLG1CQUFtQjtBQUN6QyxPQUFPLGNBQWMsaUJBQWlCO0FBRXRDLE9BQU8saUJBQWlCLDBCQUEwQjtBQUNsRCxPQUFPLGlCQUFpQixvQkFBb0I7QUFFNUMsTUFBTSxNQUFNLFVBQVU7SUFBRSxTQUFTO1FBQUMsWUFBWTtLQUFhO0FBQUMifQ==